
module load vital-it/7
module load UHTS/Analysis/SeqKit/0.13.2
seqkit fx2tab --length --name --header-line RAS_bin_ref_extra.fasta > RAS_bin_ref_extra_STATS.txt
 
