

## Consolidate & Process CheckM data from multiple tools

## Home directory contains subdirectories for each tool & a 'RESULTS' subdirectory to collect results
## 01_MetaBAT2  02_MaxBin2  03_CONCOCT  04_MetaMax  05_MetaCon  06_MaxCon  07_MetaMaxCon  RESULTS

HOME="/storage/scratch/users/rj23k073/04_DEER/09_CheckM"

DATASET="deer"



## ##
setwd(HOME)

list_of_tools <- grep(list.files(), pattern='RESULTS', invert=TRUE, value=TRUE)

master_array <- data.frame(array(NA, dim = c(0,12), dimnames = list(c(),c("sample","bin.size","bin","marker lineage","num.genomes","complete","contam","scaffolds","N50","GC","coding.density","Tool"))))

for(t in 1:length(list_of_tools)){

INDIR=paste0(HOME,"/",list_of_tools[t])

tool <- gsub(".*_","",list_of_tools[t])

setwd(INDIR)

sample_list <- list.files(pattern=glob2rx("*_checkm"))

results_array <- data.frame(array(NA, dim = c(0,14), dimnames = list(c(),c("sample",DATASET,"env","bin.size","bin","marker lineage","num.genomes","complete","contam","scaffolds","N50","GC","coding.density","Tool"))))

for(i in 1:length(sample_list)){
  
  sample22 <- sample_list[i]
  
  sample44 <- sub("_checkm.*","",sample22)
  
  setwd(paste0(INDIR,"/",sample22,"/storage"))
  
  stats_thing <- read.table("bin_stats_ext.tsv", header = F, stringsAsFactors = F, sep = "\t")

  bin_size <- dim(stats_thing)[1]
  
  results_temp <- data.frame(array(NA, dim = c(bin_size,14), dimnames = list(c(),c("sample","deer","env","bin.size","bin","marker lineage","num.genomes","complete","contam","scaffolds","N50","GC","coding.density","tool"))))
  results_temp[,1] <- sample44
  results_temp[,2] <- sub("_.*","",sample44)
  results_temp[,3] <- sub(".*_","",sample44)
  results_temp[,4] <- bin_size
  results_temp[,14] <- tool
  
  for(j in 1:bin_size){
    
    results_temp[j,5] <- as.numeric(gsub(paste0("bin.|maxbin.|",sample44,"_"),"",stats_thing[j,1]))
    
    stats_line <- stats_thing[j,2]
    
    root2 <- gsub(".*marker lineage: |, # genomes.*","",stats_line)
    genomes2 <- as.numeric(gsub(".*# genomes: |, # markers.*","",stats_line))
    complete2 <- as.numeric(gsub(".*Completeness: |, Contamination.*","",stats_line))
    contam2 <- as.numeric(gsub(".*Contamination: |, GC.*","",stats_line))
    scaffolds2 <- as.numeric(gsub(".*scaffolds: |, # contigs.*","",stats_line))
    N50 <- as.numeric(gsub(".*N50 \\(scaffolds\\): |, N50 \\(contigs\\).*","",stats_line))
    GC <- as.numeric(gsub(".*, GC: |, GC std:.*","",stats_line))
    Coding2 <- as.numeric(gsub(".*Coding density: |, Translation table: .*","",stats_line))
    
    results_temp[j,6] <- root2
    results_temp[j,7] <- genomes2
    results_temp[j,8] <- complete2
    results_temp[j,9] <- contam2
    results_temp[j,10] <- scaffolds2
    results_temp[j,11] <- N50
    results_temp[j,12] <- GC
    results_temp[j,13] <- Coding2
    
  }
  
  results_temp2 <- results_temp[order(results_temp$bin),]

  results_array <- rbind(results_array,results_temp2)
}

# tool-specific results
setwd(paste0(HOME,"/RESULTS"))
write.csv(results_array,paste0("CheckM_",tool,"_Results.csv"), row.names = F)

  if(t==1){master_array <- results_array} else {
    
    master_array <- rbind(master_array, results_array)
  }


} 

# consolidated results
setwd(paste0(HOME,"/RESULTS"))
write.csv(master_array,paste0("CHECKM_FULL_RESULTS.csv"), row.names = F)




