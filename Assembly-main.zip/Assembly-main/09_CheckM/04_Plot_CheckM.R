
library(ggplot2)
library(RColorBrewer)
library(ggpubr)


## sample list 
## 1-7 deer for 1-10 environments
sample_list <- paste0(rep(1:7, each=10),"_",1:10)

## ADJUST setwd() a couple times etc

## ADJUST tool names, combinations of tools names etc

## ADJUST annotate_figure() title 



## ##
cols <- rev(brewer.pal(11, "RdBu"))

setwd("~/Dropbox/My Mac (Russs-MacBook-Air.local)/Desktop/BERN/RESULTS/DEER/09_CheckM/data")

results_df <- read.csv("CHECKM_FULL_RESULTS.csv", header = T, stringsAsFactors = F)

results_df$complete <- results_df$complete/100
results_df$Contamination <- results_df$contam/100
results_df[results_df$Contamination>1,"Contamination"] <- 1

results_df$tool2 <- factor(results_df$tool, levels = c("MetaBAT2","MaxBin2","CONCOCT","MetaMax","MetaCon","MaxCon","MetaMaxCon"))



check_plot_list <- list()
check_count <- 1

for(i in 1:length(sample_list)){
  
  deer <- sub("_.*","",sample_list[i])
  
  env <- sub(".*_","",sample_list[i])
  
  data44 <- results_df[results_df$sample==sample_list[i],]
  
  miny <- min(data44$N50)*0.95
  maxy <- max(data44$N50)*1.05
  
  
  small_list <- list()
  small_counter <- 1
  
  for(t in 1:length(unique(results_df$tool2))){
    
    data88 <- data44[data44$tool2 == unique(results_df$tool2)[t],]
    
    p1 <- ggplot(data88, aes(complete,N50, col=Contamination)) + geom_point() +
      theme(panel.background = element_rect(fill = "white")) +
      theme(panel.border = element_rect(colour = "black", fill=NA, size=0.5)) +
      theme(axis.text = element_text(size = 10),axis.title=element_text(size=11),plot.title=element_text(size=12,face = "bold"), legend.title = element_text(size=11), legend.text = element_text(size=10)) +
      scale_color_gradientn(colours = cols, limits=c(0,1)) + 
      scale_size_continuous(limits = c(0,1)) +
      xlab("Completeness") + ylab("N50") +
      scale_y_continuous(trans = "log10", limits = c(miny, maxy)) +
      xlim(0,1) +
      ggtitle(unique(results_df$tool2)[t])
    
    
    if(t %in% c(1:4)){p1 <- p1 + xlab("")}
    
    if(t %in% c(2,3,5,6)){p1 <- p1 + ylab("")}
    
    small_list[[small_counter]] <- p1
    small_counter <- small_counter + 1
    
  }
  
  bar_chart_df <- data.frame(tapply(data44$bin.size, data44$tool2, mean))
  colnames(bar_chart_df) <- "bin.size"
  bar_chart_df$tool2 <- rownames(bar_chart_df)
  bar_chart_df$tool2 <- factor(bar_chart_df$tool2, levels = c("MetaBAT2","MaxBin2","CONCOCT","MetaMax","MetaCon","MaxCon","MetaMaxCon"))
  
  p2 <- ggplot(bar_chart_df, aes(tool2, bin.size, fill=tool2)) + geom_bar(stat = "identity", col="black") +
    theme(panel.background = element_rect(fill = "white")) +
    theme(panel.border = element_rect(colour = "black", fill=NA, size=0.5)) +
    theme(axis.title.x=element_blank(),axis.text.x=element_blank(),axis.ticks.x=element_blank()) +
    ylab("\nNumber of Bins") +
    theme(legend.position = "none") +
    scale_fill_brewer(palette="Set2") +
    geom_text(label=bar_chart_df$tool2, angle=90, y = (max(bar_chart_df$bin.size)*.24)) +
    ggtitle(" ")
  
  
  
  tt1 <- ggarrange(small_list[[1]],small_list[[2]],small_list[[3]],
                   small_list[[4]],small_list[[5]],small_list[[6]],
                   small_list[[7]], p2, 
                   nrow = 3, ncol = 3,
                   common.legend = TRUE, legend="right")
  
  
  tt2 <- annotate_figure(tt1, fig.lab = paste0("Deer ", deer," Environment ", env,"\n"), 
                         fig.lab.pos="bottom.right", fig.lab.size = 18, fig.lab.face = "bold")
  
  
  check_plot_list[[check_count]] <- tt2
  check_count <- check_count + 1
  
}


setwd("~/Dropbox/My Mac (Russs-MacBook-Air.local)/Desktop/BERN/RESULTS/DEER/09_CheckM")
pdf("Bin_Qualities.pdf", width = 14, height = 8.5)
for(i in 1:length(check_plot_list)){
  print(check_plot_list[[i]])
}
dev.off()
