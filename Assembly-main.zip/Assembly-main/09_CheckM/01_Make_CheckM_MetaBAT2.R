INDIR="/storage/scratch/users/rj23k073/04_DEER/08_Binning/01_MetaBAT2"
OUTDIR="/storage/scratch/users/rj23k073/04_DEER/09_CheckM/01_MetaBAT2"

DATASET="deer"


setwd(INDIR)

Read_list <- list.files(pattern=glob2rx(paste0("*",DATASET,"_metabat")))

setwd(OUTDIR)
for(i in 1:length(Read_list)){
  
  reads1 <- Read_list[i]
  
  sub_reads1 <- sub(paste0("_",DATASET,".*"),"",reads1)
  
  sh_name <- paste0(sub_reads1,"_checkm_metabat2.sh")
  
  code_block <- paste0("checkm lineage_wf scaffolds_filtered.fasta.metabat* ",OUTDIR,"/",sub_reads1,"_checkm -x fa -t 1")
  
  
  write ("#!/bin/bash", sh_name)
  write ("#SBATCH --mem=60000M", sh_name, append = TRUE)
  write ("#SBATCH --nodes=1", sh_name, append = TRUE)
  write ("#SBATCH --ntasks=1", sh_name, append = TRUE)
  write ("#SBATCH --cpus-per-task=1", sh_name, append = TRUE)
  write ("#SBATCH --time=03:00:00", sh_name, append = TRUE)
  write ("#SBATCH --mail-user=<russell.jasper@unibe.ch>", sh_name, append = TRUE)
  write ("#SBATCH --mail-type=FAIL,END", sh_name, append = TRUE)
  write ("#SBATCH --output=slurm-%x.%j.out", sh_name, append = TRUE)
  write ("module load vital-it/7", sh_name, append = TRUE)
  write ("module load SequenceAnalysis/GenePrediction/prodigal/2.6.3", sh_name, append = TRUE)
  write ("module load SequenceAnalysis/HMM-Profile/hmmer/3.1b2", sh_name, append = TRUE)
  write ("module load UHTS/Analysis/pplacer/1.1.alpha19", sh_name, append = TRUE)
  write ("module load Python/3.10.8-GCCcore-12.2.0", sh_name, append = TRUE)
  write (paste0("cd ",INDIR,"/",reads1), sh_name, append = TRUE)
  write (code_block, sh_name, append = TRUE)
  
}
