#!/bin/bash
#SBATCH --mem=100M
#SBATCH --time=01:20:00
#SBATCH --nodes=1
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=1
#SBATCH --mail-user=<russell.jasper@unibe.ch>
#SBATCH --mail-type=FAIL,END
#SBATCH --output=slurm-%x.%j.out


INDIR=/storage/scratch/users/rj23k073/04_DEER/08_Binning
OUTDIR=/storage/scratch/users/rj23k073/04_DEER/10_DAS_Tool

cd $OUTDIR

for i in $(cat redux_sample_list.txt)
do

 mkdir $i

 /storage/scratch/users/rj23k073/programs/DAS_Tool/src/Fasta_to_Contig2Bin.sh -i "$INDIR"/01_MetaBAT2/"$i"_*_metabat/scaffolds_filtered.fasta.metabat-bins* -e fa > "$OUTDIR"/"$i"/"$i"_metabat_contigs2bin.tsv

 /storage/scratch/users/rj23k073/programs/DAS_Tool/src/Fasta_to_Contig2Bin.sh -i "$INDIR"/02_MaxBin2/"$i"_*_maxbin/ -e fasta > "$OUTDIR"/"$i"/"$i"_maxbin_contigs2bin.tsv

 /storage/scratch/users/rj23k073/programs/DAS_Tool/src/Fasta_to_Contig2Bin.sh -i "$INDIR"/03_CONCOCT/"$i"_*_concoct/concoct_output/fasta_bins -e fa > "$OUTDIR"/"$i"/"$i"_concoct_contigs2bin.tsv

 /storage/scratch/users/rj23k073/programs/DAS_Tool/src/Fasta_to_Contig2Bin.sh -i "$INDIR"/04_MetaMax/"$i"_Binning_refiner_outputs/"$i"_refined_bins -e fasta > "$OUTDIR"/"$i"/"$i"_metamax_contigs2bin.tsv

 /storage/scratch/users/rj23k073/programs/DAS_Tool/src/Fasta_to_Contig2Bin.sh -i "$INDIR"/05_MetaCon/"$i"_Binning_refiner_outputs/"$i"_refined_bins -e fasta > "$OUTDIR"/"$i"/"$i"_metacon_contigs2bin.tsv

 /storage/scratch/users/rj23k073/programs/DAS_Tool/src/Fasta_to_Contig2Bin.sh -i "$INDIR"/06_MaxCon/"$i"_Binning_refiner_outputs/"$i"_refined_bins -e fasta > "$OUTDIR"/"$i"/"$i"_maxcon_contigs2bin.tsv

 /storage/scratch/users/rj23k073/programs/DAS_Tool/src/Fasta_to_Contig2Bin.sh -i "$INDIR"/07_MetaMaxCon/"$i"_Binning_refiner_outputs/"$i"_refined_bins -e fasta > "$OUTDIR"/"$i"/"$i"_metamaxcon_contigs2bin.tsv

 echo Done $i

done
