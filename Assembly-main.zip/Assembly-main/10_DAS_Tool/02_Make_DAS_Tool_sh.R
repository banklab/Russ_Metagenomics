
DATASET="deer"

ASMDIR="/storage/scratch/users/rj23k073/04_DEER/06_Assembly"
INDIR="/storage/scratch/users/rj23k073/04_DEER/10_DAS_Tool"

setwd(INDIR)

Read_list <- read.table("redux_sample_list.txt", header=F)[,1]


for(i in 1:length(Read_list)){
  
  reads1 <- Read_list[i]
  
  sh_name <- paste0(reads1,"_dastool.sh")
  
  code_block <- paste0("/storage/scratch/users/rj23k073/programs/DAS_Tool/DAS_Tool -i ",reads1,"_metabat_contigs2bin.tsv,",reads1,"_maxbin_contigs2bin.tsv,",reads1,"_concoct_contigs2bin.tsv,",reads1,"_metamax_contigs2bin.tsv,",reads1,"_metacon_contigs2bin.tsv,",reads1,"_maxcon_contigs2bin.tsv,",reads1,"_metamaxcon_contigs2bin.tsv -l metabat,maxbin,concoct,metamax,metacon,maxcon,metamaxcon -c ",ASMDIR,"/",reads1,"_",DATASET,".asm/scaffolds_filtered.fasta -o ",reads1,"_",DATASET," -t 6 --write_bins")
  
  
  write ("#!/bin/bash", sh_name)
  write ("#SBATCH --mem=2000M", sh_name, append = TRUE)
  write ("#SBATCH --nodes=1", sh_name, append = TRUE)
  write ("#SBATCH --ntasks=1", sh_name, append = TRUE)
  write ("#SBATCH --cpus-per-task=6", sh_name, append = TRUE)
  write ("#SBATCH --time=00:20:00", sh_name, append = TRUE)
  write ("#SBATCH --mail-user=<russell.jasper@unibe.ch>", sh_name, append = TRUE)
  write ("#SBATCH --mail-type=FAIL,END", sh_name, append = TRUE)
  write ("#SBATCH --output=slurm-%x.%j.out", sh_name, append = TRUE)
  write ("module load vital-it/7", sh_name, append = TRUE)
  write ("module load SequenceAnalysis/GenePrediction/prodigal/2.6.3", sh_name, append = TRUE)
  write ("module load SequenceAnalysis/SequenceSearch/diamond/2.0.9", sh_name, append = TRUE)
  write ("module load R", sh_name, append = TRUE)
  write ("export PATH=$PATH:/storage/scratch/users/rj23k073/programs/pullseq/pullseq/src", sh_name, append = TRUE)
  write (paste0("cd ",INDIR,"/",reads1), sh_name, append = TRUE)
  write (code_block, sh_name, append = TRUE)
  write (paste0("echo Done ",reads1), sh_name, append = TRUE)
  
}
