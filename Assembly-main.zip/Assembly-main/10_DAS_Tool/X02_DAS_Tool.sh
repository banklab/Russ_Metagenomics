#!/bin/bash
#SBATCH --mem=4000M
#SBATCH --time=02:00:00
#SBATCH --nodes=1
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=10
#SBATCH --mail-user=<russell.jasper@unibe.ch>
#SBATCH --mail-type=FAIL,END
#SBATCH --output=slurm-%x.%j.out
module load vital-it/7
module load SequenceAnalysis/GenePrediction/prodigal/2.6.3
module load SequenceAnalysis/SequenceSearch/diamond/2.0.9
module load R
export PATH=$PATH:/storage/scratch/users/rj23k073/programs/pullseq/pullseq/src

DATASET=deer

ASMDIR=/storage/scratch/users/rj23k073/04_DEER/06_Assembly
INDIR=/storage/scratch/users/rj23k073/04_DEER/10_DAS_Tool

cd $INDIR

for i in $(cat redux_sample_list.txt)
do
/storage/scratch/users/rj23k073/programs/DAS_Tool/DAS_Tool -i "$INDIR"/"$i"/"$i"_metabat_contigs2bin.tsv,\
"$INDIR"/"$i"/"$i"_maxbin_contigs2bin.tsv,\
"$INDIR"/"$i"/"$i"_concoct_contigs2bin.tsv,\
"$INDIR"/"$i"/"$i"_metamax_contigs2bin.tsv,\
"$INDIR"/"$i"/"$i"_metacon_contigs2bin.tsv,\
"$INDIR"/"$i"/"$i"_maxcon_contigs2bin.tsv,\
"$INDIR"/"$i"/"$i"_metamaxcon_contigs2bin.tsv \
-l metabat,maxbin,concoct,metamax,metacon,maxcon,metamaxcon \
-c "$ASMDIR"/"$i"_"$DATASET".asm/scaffolds_filtered.fasta \
-o $i -t 10
echo Done $i
done



