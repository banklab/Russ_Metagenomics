
conda activate mosdepth


for i in *sorted.bam
do
file2=$(echo $i | perl -pe 's/\.sorted.bam//')
echo $file2
mosdepth -b 1000 $file2 $i
done


gunzip *regions.bed.gz
