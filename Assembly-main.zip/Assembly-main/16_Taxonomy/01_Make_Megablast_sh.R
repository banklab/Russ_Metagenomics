
BLAST_DIR="/storage/workspaces/vetsuisse_fiwi_mico4sys/fiwi_mico4sys001/metagenomics/programs/blast/ncbi-blast-2.15.0+/bin"
DB_DIR="/storage/workspaces/vetsuisse_fiwi_mico4sys/fiwi_mico4sys001/metagenomics/programs/blast/Database/nt"

INPUT_DIR="/storage/scratch/users/rj23k073/01_RAS/16_Taxonomy/genomes"
OUTPUT_DIR="/storage/scratch/users/rj23k073/01_RAS/16_Taxonomy/01_Blast_outputs"

DATASET="RAS"

setwd(INPUT_DIR)
species_list <- list.files(pattern = "fa")


setwd(OUTPUT_DIR)
for(i in 1:length(species_list)){
  
  choose_species <- species_list[i]

  sh_name <- gsub("fa","sh",choose_species)
  
  code_block <- paste0(BLAST_DIR,"/blastn -db ",DB_DIR," -query ",INPUT_DIR,"/",choose_species," -out ",paste0(DATASET,"_",gsub("fa","out",choose_species))," -num_threads 1 -outfmt '6 qseqid qstart qend qlen sseqid staxids sstart send bitscore evalue nident length' -task megablast")
  
  
  write ("#!/bin/bash", sh_name)
  write ("#SBATCH --mem=10000M", sh_name, append = TRUE)
  write ("#SBATCH --nodes=1", sh_name, append = TRUE)
  write ("#SBATCH --ntasks=1", sh_name, append = TRUE)
  write ("#SBATCH --cpus-per-task=1", sh_name, append = TRUE)
  write ("#SBATCH --time=8:00:00", sh_name, append = TRUE)
  write ("#SBATCH --mail-user=<russell.jasper@unibe.ch>", sh_name, append = TRUE)
  write ("#SBATCH --mail-type=FAIL,END", sh_name, append = TRUE)
  write ("#SBATCH --output=slurm-%x.%j.out", sh_name, append = TRUE)
  #write ("#SBATCH --partition=pibu_el8", sh_name, append = TRUE)
  write (code_block, sh_name, append = TRUE)
  write ("echo 'Finished Blast'", sh_name, append = TRUE)
  
}
