#!/bin/bash
#SBATCH --mem=4000M
#SBATCH --nodes=1
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=1
#SBATCH --time=00:30:00
#SBATCH --mail-user=<russell.jasper@unibe.ch>
#SBATCH --mail-type=FAIL,END
#SBATCH --output=slurm-%x.%j.out
TAXDUMP=/storage/scratch/users/rj23k073/04_DEER/16_Taxonomy/ncbi_tax
export TAXATORTK_TAXONOMY_NCBI=$TAXDUMP
module load Python/3.10.8-GCCcore-12.2.0
cat deer_megablast_out.tab | taxator -a megan-lca -t 0.3 -e 0.01 -g deer_mapping.tax > deer_predictions.gff3
sort -k1,1 deer_predictions.gff3 | binner -n classification -i genus:0.6 > deer_binned_predictions.txt
cat deer_binned_predictions.txt | taxknife -f 2 --mode annotate -s path | grep -v "Could not" | cut -f1,2 > deer_contig_taxonomy.tab
python classify_bins.py deer_contig_taxonomy.tab /storage/scratch/users/rj23k073/04_DEER/REFERENCES/dRep_ONLY_bin_ref_fastANI_genomes/ > deer_bin_taxonomy.tab
