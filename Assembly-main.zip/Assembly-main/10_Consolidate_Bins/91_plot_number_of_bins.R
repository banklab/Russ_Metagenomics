
library()


consolidate_bins_df <- read.table("bins_by_env.txt", header = F, stringsAsFactors = F)

consolidate_bins_df$Deer <- gsub("_.*","",consolidate_bins_df$V2)
consolidate_bins_df$Env <- gsub(".*_","",consolidate_bins_df$V2)

consolidate_bins_df$Env2 <- factor(consolidate_bins_df$Env, levels=c(1:10))

p1 <- ggplot(consolidate_bins_df, aes(Env2, V1, group=Deer)) + 
  theme(panel.background = element_rect(fill = "white")) +
  xlab("Environment") + ylab("Number of Bins") +
  scale_x_discrete(labels=c(rep(1:10, times=7))) +
  theme(panel.border = element_rect(colour = "black", fill=NA, size=0.5)) +
  geom_bar(stat = "identity", fill="grey", col="black", width=0.8)

p1 + facet_grid( ~ Deer,  space  = "free", scales = "free", 
                    drop = TRUE, shrink = TRUE)



ggplot(consolidate_bins_df, aes(Env2, V1)) + geom_boxplot() + 
  theme(panel.background = element_rect(fill = "white")) +
  xlab("Environment") + ylab("Number of Bins") +
  theme(panel.border = element_rect(colour = "black", fill=NA, size=0.5))



