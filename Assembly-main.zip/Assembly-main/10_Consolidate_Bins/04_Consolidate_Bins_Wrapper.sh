#!/bin/bash
#SBATCH --mem=100M
#SBATCH --nodes=1
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=1
#SBATCH --time=03:00:00
#SBATCH --mail-user=<russell.jasper@unibe.ch>
#SBATCH --mail-type=FAIL,END
#SBATCH --output=slurm-%x.%j.out
module load Python/3.10.8-GCCcore-12.2.0

for i in $(cat redux_sample_list.txt)
do

mkdir 03_Temp_Winner/"$i"_RAS

python consolidate_two_sets_of_bins.py 01_Bins/MetaBAT2/"$i"_RAS_metabat 01_Bins/MaxBin2/"$i"_RAS_maxbin 02_Stats/MetaBAT2/"$i"_MetaBAT2.stats 02_Stats/MaxBin2/"$i"_MaxBin2.stats 03_Temp_Winner/"$i"_RAS/round1 70 10

python consolidate_two_sets_of_bins.py 03_Temp_Winner/"$i"_RAS/round1 01_Bins/CONCOCT/"$i"_RAS_concoct 03_Temp_Winner/"$i"_RAS/round1.stats 02_Stats/CONCOCT/"$i"_CONCOCT.stats 03_Temp_Winner/"$i"_RAS/round2 70 10

python consolidate_two_sets_of_bins.py 03_Temp_Winner/"$i"_RAS/round2 01_Bins/MaxCon/"$i"_Binning_refiner_outputs 03_Temp_Winner/"$i"_RAS/round2.stats 02_Stats/MaxCon/"$i"_MaxCon.stats 03_Temp_Winner/"$i"_RAS/round3 70 10

python consolidate_two_sets_of_bins.py 03_Temp_Winner/"$i"_RAS/round3 01_Bins/MetaCon/"$i"_Binning_refiner_outputs 03_Temp_Winner/"$i"_RAS/round3.stats 02_Stats/MetaCon/"$i"_MetaCon.stats 03_Temp_Winner/"$i"_RAS/round4 70 10

python consolidate_two_sets_of_bins.py 03_Temp_Winner/"$i"_RAS/round4 01_Bins/MetaMax/"$i"_Binning_refiner_outputs 03_Temp_Winner/"$i"_RAS/round4.stats 02_Stats/MetaMax/"$i"_MetaMax.stats 03_Temp_Winner/"$i"_RAS/round5 70 10

python consolidate_two_sets_of_bins.py 03_Temp_Winner/"$i"_RAS/round5 01_Bins/MetaMaxCon/"$i"_Binning_refiner_outputs 03_Temp_Winner/"$i"_RAS/round5.stats 02_Stats/MetaMaxCon/"$i"_MetaMaxCon.stats 03_Temp_Winner/"$i"_RAS/round6 70 10

mkdir 04_Top_Bins/"$i"_RAS
cp -r 03_Temp_Winner/"$i"_RAS/round6/*fa 04_Top_Bins/"$i"_RAS
cp 03_Temp_Winner/"$i"_RAS/round6.stats 04_Top_Bins/STATS/"$i".stats

echo "Done"
echo $i
done
