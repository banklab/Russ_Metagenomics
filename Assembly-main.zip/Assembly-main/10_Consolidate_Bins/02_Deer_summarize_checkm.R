
## 'deer' hardcoded in some filepaths
## paths to specific tools' bins hardcoded
## make the directories for each tool in Summarize_CheckM first

tools <- c("01_MetaBAT2","02_MaxBin2","03_CONCOCT","04_MetaMax","05_MetaCon","06_MaxCon","07_MetaMaxCon")


BIN_DIR="/storage/scratch/users/rj23k073/04_DEER/10_Consolidate_Bins/01_Bins"
CHECKM_DIR="/storage/scratch/users/rj23k073/04_DEER/09_CheckM"

OUTDIR="/storage/scratch/users/rj23k073/04_DEER/09_CheckM/Summarize_CheckM"


Read_list <- paste0(rep(1:7, each=10), "_",1:10)
## Read_list <- gsub("_RAS.*","",list.files(pattern="RAS.asm"))


sh_name <- paste0("Deer_summarize_checkm.sh")




## ##

setwd(OUTDIR)

write ("#!/bin/bash", sh_name)
write ("#SBATCH --mem=100M", sh_name, append = TRUE)
write ("#SBATCH --nodes=1", sh_name, append = TRUE)
write ("#SBATCH --ntasks=1", sh_name, append = TRUE)
write ("#SBATCH --cpus-per-task=1", sh_name, append = TRUE)
write ("#SBATCH --time=00:05:00", sh_name, append = TRUE)
write ("#SBATCH --mail-user=<russell.jasper@unibe.ch>", sh_name, append = TRUE)
write ("#SBATCH --mail-type=FAIL,END", sh_name, append = TRUE)
write ("#SBATCH --output=slurm-%x.%j.out", sh_name, append = TRUE)
write ("module load vital-it/7", sh_name, append = TRUE)
write ("module load Python/3.10.8-GCCcore-12.2.0", sh_name, append = TRUE)


for(i in 1:length(Read_list)){
  
  reads1 <- Read_list[i]
  
   
  for(t in 1:length(tools)){
    
    tool2 <- tools[t]
    
    checkm_dir <- paste0(CHECKM_DIR,"/",tool2,"/",reads1,"_*checkm/storage")
    
    bins_dir <- paste0(BIN_DIR,"/",gsub(".*_","",tool2),"/",reads1,"_*")
    
    outfile <- paste0(reads1,"_",gsub(".*_","",tool2),".stats")
    
    code_block <- paste0("python summarize_checkm.py ", checkm_dir, "/bin_stats_ext.tsv ", bins_dir, " | (read -r; printf \"%s\\n\" \"$REPLY\"; sort) > ", OUTDIR, "/", tool2, "/", outfile)
    
    write (code_block, sh_name, append = TRUE)
    
  }
  
}
